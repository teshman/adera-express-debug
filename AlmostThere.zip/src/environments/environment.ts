
export const environment = {
    FAQ_ID: `piggyback`,
    production: false,
    SENDGRID_API_KEY: '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',
    firebase: {
      vapidKey: `BLxYDFXtyb2YhgicW9fIJfNr0uvfUIKfSW3zHAr2TqArGahBgXnW6vsIkvYO2PVjawMb47p9uJ3GWSq4sQHmkK4`,
      apiKey: "AIzaSyDs6nqJUdgWRDo93a3aGgQVR0dEsFBPlRE",
      authDomain: "adera-melakia.firebaseapp.com",
      projectId: "adera-melakia",
      storageBucket: "adera-melakia.firebasestorage.app",
      messagingSenderId: "204956773748",
      appId: "1:204956773748:web:dc988b129a4abcf21ed021",
      measurementId: "G-B8B5PV54RG"
      },
      stripe: {
        publicKey: "pk_test_51RMNPO2Lg2jrxk6lKT4W2njTrlk2mOxOEwlg5v6lP7qcEtGEQP3zL0cdUT7H7V9CMhHC4YGA2sPsz7jJQjuvol4g00F5v0PHrL", // Stripe test publishable key
        stripePublishableKey: `pk_test_51RMNPO2Lg2jrxk6lKT4W2njTrlk2mOxOEwlg5v6lP7qcEtGEQP3zL0cdUT7H7V9CMhHC4YGA2sPsz7jJQjuvol4g00F5v0PHrL`,
        apiVersion: "2023-08-16" // Optional: Match backend API version
      },
    apiUrl:  ' https://us-central1-adera-melakia.cloudfunctions.net/api',
    PAYPAL_CLIENT_ID: `ATOVQFvGuy5FOSy7PETkD8Gt3XP3ETAX726a8Eauxdk8UPuAUoYjw3WfCPrONlu-jPySQHDu8VY_uEBg`,
    PAYPAL_CLIENT_SECRET: `EOJC-3AnIKp64PN8dIk1FCJn_vLKaYm8iOYbFu7DQMsXN37Wzxs1wHDLNQlKndsF0l8idrfUOStsaeK1`,
    cloudFunctionSecret:'THE_G00D_THE_B@D_THE_UGLY',
    VITE_PAYPAL_SERVER_URL: `http://localhost:8080`
};

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyDs6nqJUdgWRDo93a3aGgQVR0dEsFBPlRE",
  authDomain: "adera-melakia.firebaseapp.com",
  projectId: "adera-melakia",
  storageBucket: "adera-melakia.firebasestorage.app",
  messagingSenderId: "204956773748",
  appId: "1:204956773748:web:dc988b129a4abcf21ed021",
  measurementId: "G-B8B5PV54RG"
  };


  