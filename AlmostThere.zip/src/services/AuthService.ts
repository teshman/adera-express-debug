// src/services/AuthService.ts

import auth, { FirebaseAuthTypes } from '@react-native-firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { environment } from '../environments/environment';
import { UserRole, CustomClaims, UserData } from '../models/types';

// Define a type for the callback function that listens to auth state changes
type AuthStateChangeCallback = (user: FirebaseAuthTypes.User | null) => void;

// Define AuthListenerUnsubscriber explicitly as a function that takes no arguments and returns void
// This bypasses potential inference issues and directly matches the expected type of the unsubscribe function
type AuthListenerUnsubscriber = () => void;


class AuthService {
    private apiUrl: string = environment.apiUrl;
    private currentUser: FirebaseAuthTypes.User | null = null;
    private userRoles: string[] | null = null;
    private isAnonymous: boolean = false;
    // New: Array to hold auth state change callbacks
    private authStateChangeCallbacks: AuthStateChangeCallback[] = [];
    // New: Firebase's own unsubscribe function, now with explicit type
    private firebaseAuthUnsubscribe: AuthListenerUnsubscriber | null = null;

  private static instance: AuthService
    constructor() {
        this.setupAuthStateListener();
        this.initializeUserFromStorage();
    }
public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }
    /**
     * Sets up a listener for Firebase authentication state changes.
     * This is the primary way to keep the app's auth state in sync with Firebase.
     * It also manages our internal callback array.
     */
    private setupAuthStateListener(): void {
        // Store Firebase's own unsubscribe function
        this.firebaseAuthUnsubscribe = auth().onAuthStateChanged(async (user) => {
            this.currentUser = user;
            this.isAnonymous = user?.isAnonymous || false;

            // Notify all subscribed components
            this.authStateChangeCallbacks.forEach(callback => {
                try {
                    callback(user);
                } catch (e) {
                    console.error('Error in auth state change callback:', e);
                }
            });

            if (user) {
                console.log('Firebase Auth State Changed: User logged in', user.uid);
                await this.handleAuthenticatedUser(user);
            } else {
                console.log('Firebase Auth State Changed: User logged out');
                await this.handleUnauthenticatedUser();
            }
        });
    }

    /**
     * Attempts to load user state from AsyncStorage on app startup.
     */
    private async initializeUserFromStorage(): Promise<void> {
        try {
            const storedUser = await AsyncStorage.getItem('currentUser');
            if (storedUser) {
                const userData: UserData = JSON.parse(storedUser);
                console.log('User data initialized from storage:', userData.uid);
            }
            const wasAnonymous = await AsyncStorage.getItem('wasAnonymous');
            this.isAnonymous = wasAnonymous === 'true';
        } catch (error) {
            console.error('Failed to initialize user state from storage:', error);
            await this.clearStoredUser();
        }
    }

    /**
     * Handles logic for an authenticated user, including token validation and role loading via Cloud Functions.
     * @param user The authenticated Firebase User object.
     */
    private async handleAuthenticatedUser(user: FirebaseAuthTypes.User): Promise<void> {
        try {
            // 1. Validate auth token on the server
            const isValidToken = await this.validateAuthToken(user);
            if (!isValidToken) {
                await this.logout();
                return;
            }

            // 2. Load user roles from Cloud Function
            this.userRoles = await this.loadUserRoles(user.uid);
            console.log('User roles loaded:', this.userRoles);

            // 3. Save basic user data to AsyncStorage
            await AsyncStorage.setItem('currentUser', JSON.stringify({
                uid: user.uid,
                email: user.email,
                role: this.userRoles && this.userRoles.length > 0 ? this.userRoles[0] : 'default'
            }));
            await AsyncStorage.setItem('wasAnonymous', String(user.isAnonymous));

        } catch (error) {
            console.error('Error handling authenticated user:', error);
            await this.logout();
        }
    }

    /**
     * Handles logic for an unauthenticated user, clearing state.
     */
    private async handleUnauthenticatedUser(): Promise<void> {
        this.currentUser = null;
        this.userRoles = null;
        this.isAnonymous = false;
        await this.clearStoredUser();
    }

    /**
     * Clears all user-related data from AsyncStorage.
     */
    private async clearStoredUser(): Promise<void> {
        try {
            await AsyncStorage.removeItem('currentUser');
            await AsyncStorage.removeItem('wasAnonymous');
            console.log('Cleared user data from AsyncStorage.');
        } catch (error) {
            console.error('Error clearing stored user data:', error);
        }
    }

    /**
     * Gets the current Firebase User object.
     * @returns The current Firebase User or null.
     */
    getCurrentUser(): FirebaseAuthTypes.User | null {
        return this.currentUser;
    }

    /**
     * Gets the current user's ID.
     * @returns The user's UID or an empty string if no user.
     */
    getCurrentUserId(): string {
        return this.currentUser?.uid || '';
    }

    /**
     * Checks if the current session is anonymous.
     * @returns True if anonymous, false otherwise.
     */
    isAnonymousSession(): boolean {
        return this.isAnonymous;
    }

    /**
     * Subscribes a callback function to authentication state changes.
     * @param callback Function to call on auth state change.
     * @returns Unsubscribe function to stop listening.
     */
    onAuthStateChange(callback: AuthStateChangeCallback): () => void {
        this.authStateChangeCallbacks.push(callback);
        // Return a function to unsubscribe
        return () => {
            this.authStateChangeCallbacks = this.authStateChangeCallbacks.filter(cb => cb !== callback);
        };
    }

    /**
     * Disposes of the Firebase auth state listener when the service is no longer needed.
     * (Useful for cleanup if the service itself were to be unmounted, less common for singletons).
     */
    dispose(): void {
        if (this.firebaseAuthUnsubscribe) {
            this.firebaseAuthUnsubscribe(); // This should now be correctly typed as callable
            this.firebaseAuthUnsubscribe = null;
        }
        this.authStateChangeCallbacks = []; // Clear all callbacks
    }


    // --- Core Authentication Methods (using React Native Firebase Auth) ---

    /**
     * Registers a new user with email and password via Cloud Function.
     * Calls `/auth/registerUser` endpoint.
     * @param email User's email.
     * @param password User's password.
     * @param roles Array of roles for the user.
     * @returns Promise with success status and userId.
     */
    async registerUser(
        email: string,
        password: string,
        roles: ('admin' | 'requester' | 'bidder' | 'carrier')[]
    ): Promise<{ success: boolean; userId?: string }> {
        try {
            const response = await fetch(`${this.apiUrl}/auth/registerUser`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, roles })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }

            const data: { success: boolean; userId: string } = await response.json();
            return { success: true, userId: data.userId };
        } catch (error: any) {
            console.error('Registration failed via Cloud Function:', error.message);
            throw error;
        }
    }

    /**
     * Logs in a user with email and password using Firebase Auth.
     * @param email User's email.
     * @param password User's password.
     * @returns Promise resolving with the Firebase User.
     */
    async login(email: string, password: string): Promise<FirebaseAuthTypes.User> {
        try {
            const userCredential = await auth().signInWithEmailAndPassword(email, password);
            console.log('User signed in via Firebase Auth:', userCredential.user.uid);
            return userCredential.user;
        } catch (error: any) {
            console.error('Firebase Auth Login error:', error.code, error.message);
            throw this.transformAuthError(error);
        }
    }

    /**
     * Logs out the current user by calling a Cloud Function and then Firebase Auth signOut.
     * Calls `/auth/logout` endpoint.
     */
    async logout(): Promise<void> {
        const userId = this.getCurrentUserId();
        try {
            if (userId) {
                console.log('Calling Cloud Function for logout:', userId);
                const response = await fetch(`${this.apiUrl}/auth/logout`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ uid: userId })
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    console.warn('Backend logout failed but proceeding with client logout:', errorData.error);
                }
            }

            console.log('Signing out from Firebase Auth...');
            await auth().signOut();
            console.log('Firebase signOut complete. State cleared.');

        } catch (error) {
            console.error('Error during logout:', error);
            throw error;
        }
    }

    /**
     * Signs in a user anonymously via Firebase Auth and sets up user data via Cloud Function.
     * Calls `/anonymous` endpoint.
     * @param requesterEmail The email to associate with the anonymous user for backend tracking.
     * @returns Promise resolving with the Firebase User.
     */
    async signInAnonymously(requesterEmail: string): Promise<FirebaseAuthTypes.User | null> {
        try {
            const result = await auth().signInAnonymously();
            this.isAnonymous = true;
            await AsyncStorage.setItem('wasAnonymous', 'true');
            
            if (result.user) {
                console.log('Anonymous user signed in:', result.user.uid);
                await this.setAnonymousUserInFirestore(result.user, requesterEmail);
            }
            return result.user;
        } catch (error) {
            console.error('Error signing in anonymously:', error);
            throw error;
        }
    }

    /**
     * Sets anonymous user data in Firestore via a Cloud Function.
     * Calls `/anonymous` endpoint.
     * @param user The Firebase User object.
     * @param requesterEmail The email to associate.
     */
    private async setAnonymousUserInFirestore(user: FirebaseAuthTypes.User, requesterEmail: string): Promise<void> {
        if (!user) return;
        try {
            const response = await fetch(`${this.apiUrl}/anonymous`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ uid: user.uid, email: requesterEmail })
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to create anonymous user via API');
            }
            console.log('Anonymous user created/updated via API:', await response.json());
        } catch (error) {
            console.error('Failed to create anonymous user in Firestore via API:', error);
            throw error;
        }
    }

    /**
     * Sends an email verification link via a Cloud Function for registration.
     * Calls `/initiate-verification` endpoint.
     * @param email User's email.
     * @param password User's password.
     * @param roles Roles for the user.
     * @returns Promise resolving with success message.
     */
    async initiateEmailVerificationForRegistration(
        email: string,
        password: string,
        roles: UserRole[]
    ): Promise<string> {
        try {
            const callbackUrl = `${this.apiUrl}/verify-registration-email-callback`; // Placeholder for deep link

            const response = await fetch(`${this.apiUrl}/initiate-verification`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password, roles, callbackUrl })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }

            const data: { success: boolean; userId: string; email: string; verificationLink: string; } = await response.json();
            if (data.success) {
                await this.handlePostRegistration(data.userId, data.email, roles);
                return `Verification email sent to ${email}`;
            } else {
                throw new Error('Registration initiation failed on server.');
            }
        } catch (error: any) {
            console.error('Error initiating email verification for registration:', error.message);
            throw error;
        }
    }

    /**
     * Handles post-registration setup (user profile, tasks) via Cloud Functions.
     * Calls `/auth/update-user` endpoint.
     * @param userId The UID of the new user.
     * @param email The user's email.
     * @param roles The user's roles.
     */
    private async handlePostRegistration(
        userId: string,
        email: string,
        roles: UserRole[]
    ): Promise<void> {
        try {
            const userData = {
                displayName: this.generateDisplayName(email),
                avatarUrl: this.generateDefaultAvatar(email),
                profileComplete: false,
                uid: userId,
                roles: roles
            };

            const response = await fetch(`${this.apiUrl}/auth/update-user`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }
            console.log('Post-registration setup (user profile) via API:', await response.json());

        } catch (error) {
            console.error('Post-registration setup failed:', error);
            throw error;
        }
    }

    // --- Data Management Methods (via Cloud Functions) ---

    /**
     * Validates the Firebase ID token on the server.
     * Calls `/auth/validate-token` endpoint.
     * @param user The Firebase User object to get the token from.
     * @returns Promise resolving to true if token is valid, false otherwise.
     */
    private async validateAuthToken(user: FirebaseAuthTypes.User): Promise<boolean> {
        try {
            const token = await user.getIdToken(true);
            console.log('Client: Sending Firebase token for validation (first 30 chars):', token.substring(0, 30) + '...');

            const response = await fetch(`${this.apiUrl}/auth/validate-token`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ token })
            });

            const data: { valid: boolean; error?: string; } = await response.json();

            if (!response.ok || !data.valid) {
                console.error('Token validation failed via Cloud Function:', data.error || response.statusText);
                return false;
            }
            console.log('Token validated successfully via Cloud Function.');
            return true;
        } catch (error) {
            console.error('Error during token validation:', error);
            return false;
        }
    }

    /**
     * Loads user roles from the Cloud Function.
     * Calls `/users/:userId/roles` endpoint.
     * @param userId The UID of the user.
     * @returns Promise resolving with an array of roles.
     */
    async loadUserRoles(userId: string): Promise<string[]> {
        try {
            const token = await this.getCurrentToken();
            if (!token) {
                console.warn('No token available to load user roles. Returning empty array.');
                return [];
            }

            const response = await fetch(`${this.apiUrl}/users/${userId}/roles`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Failed to load user roles: HTTP error! status: ${response.status}`);
            }

            const roles: string[] = await response.json();
            return roles || [];
        } catch (error) {
            console.error('Failed to load user roles via Cloud Function:', error);
            return [];
        }
    }

    /**
     * Gets the current user's ID token.
     * @returns Promise resolving with the ID token string.
     * @throws Error if no authenticated user.
     */
    private async getCurrentToken(): Promise<string> {
        const user = auth().currentUser;
        if (!user) throw new Error('No authenticated user to get token from.');
        return user.getIdToken(true);
    }

    /**
     * Sets custom claims for a user via a Cloud Function.
     * Calls `/set-custom-claims` endpoint.
     * @param uid User ID.
     * @param roles Array of roles to set.
     */
    async setCustomClaims(uid: string, roles: string[]): Promise<void> {
        try {
            const token = await this.getCurrentToken();
            const response = await fetch(`${this.apiUrl}/set-custom-claims`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ uid, roles })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Failed to set custom claims: HTTP error! status: ${response.status}`);
            }
            console.log('Custom claims set successfully via API:', await response.json());
        } catch (error) {
            console.error('Error setting custom claims via Cloud Function:', error);
            throw error;
        }
    }

    /**
     * Saves user data to Firestore via a Cloud Function.
     * Calls `/save` endpoint.
     * @param uid User ID.
     * @param data User data to save.
     */
    async saveUserData(uid: string, data: any): Promise<void> {
        try {
            const token = await this.getCurrentToken();
            const response = await fetch(`${this.apiUrl}/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ uid, data })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Failed to save user data: HTTP error! status: ${response.status}`);
            }
            console.log('User data saved via API:', await response.json());
        } catch (error) {
            console.error('Failed to save user data via Cloud Function:', error);
            throw error;
        }
    }

    /**
     * Fetches user data from Firestore via a Cloud Function.
     * Calls `/:uid` endpoint.
     * @param uid User ID.
     * @returns Promise resolving with user data or null.
     */
    async getUserData(uid: string): Promise<any> {
        try {
            const token = await this.getCurrentToken();
            // Corrected URL for fetching user data: assuming /users/:uid endpoint
            const response = await fetch(`${this.apiUrl}/users/${uid}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Failed to fetch user data: HTTP error! status: ${response.status}`);
            }

            const data: { success: boolean; data: UserData; } = await response.json();
            return data.data || null;
        } catch (error) {
            console.error('Failed to fetch user data via Cloud Function:', error);
            return null; // Return null on error
        }
    }

    /**
     * Updates user data in Firestore via a Cloud Function.
     * Calls `/auth/update-user` endpoint.
     * @param updates Object with data to update.
     * @returns Promise resolving when update is complete.
     */
    async updateUserData(updates: Record<string, any>): Promise<void> {
        const user = this.currentUser;
        if (!user) {
            throw new Error('No authenticated user to update data for.');
        }

        try {
            const token = await this.getCurrentToken();
            const response = await fetch(`${this.apiUrl}/auth/update-user`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ uid: user.uid, ...updates })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
            }
            console.log('User data updated via API:', await response.json());
        } catch (error) {
            console.error('Failed to update user data via Cloud Function:', error);
            throw error;
        }
    }

    // --- Helper / Utility Methods ---

    /**
     * Transforms Firebase Auth errors into more user-friendly messages.
     * @param error The Firebase error object.
     * @returns An Error object with a friendly message.
     */
    private transformAuthError(error: any): Error {
        switch (error.code) {
            case 'auth/user-not-found':
            case 'auth/wrong-password':
                return new Error('Invalid email or password.');
            case 'auth/email-already-in-use':
                return new Error('This email is already registered.');
            case 'auth/missing-password':
                return new Error('Password is required.');
            case 'auth/requires-recent-login':
                return new Error('Session expired. Please log in again.');
            case 'auth/invalid-credential':
                return new Error('Invalid credentials provided.');
            case 'auth/network-request-failed':
                return new Error('Network error. Please check your internet connection.');
            default:
                return new Error(error.message || 'Authentication failed. Please try again.');
        }
    }

    /**
     * Generates a display name from an email.
     * @param email The user's email.
     * @returns A generated display name.
     */
    private generateDisplayName(email: string): string {
        // Take the part before '@' and then first 3 characters, or default to 'user'
        const usernamePart = email.split('@')[0];
        const prefix = usernamePart.length > 0 ? usernamePart.substring(0, Math.min(usernamePart.length, 3)).toLowerCase() : 'user';
        // Generate a random number between 0 and 999
        const randomNumber = Math.floor(Math.random() * 1000);
        return `${prefix}${randomNumber}`;
    }

    /**
     * Generates a default avatar URL.
     * @param email The user's email.
     * @param name Optional name for avatar generation.
     * @returns A URL for a generated avatar image.
     */
    private generateDefaultAvatar(email: string, name?: string): string {
        const displayName = name || email.split('@')[0];
        return `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=random&length=2`;
    }

    // --- Role Management ---

    /**
     * Checks if the current user has a specific role.
     * This relies on `userRoles` being populated by `handleAuthenticatedUser`.
     * @param role The role to check for.
     * @returns True if the user has the role, false otherwise.
     */
    hasRole(role: string): boolean {
        return this.userRoles?.includes(role) || false;
    }
}

// Export a singleton instance of the service
export const authService = AuthService.getInstance();
