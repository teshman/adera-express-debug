// android/build.gradle.kts
// Root build file for configuring all modules and defining buildscript dependencies

plugins {
    id("com.android.application") version "8.4.0" apply false // Android Gradle Plugin version
    // The com.facebook.react plugin is applied directly from node_modules via includeBuild in settings.gradle.kts
    // DO NOT add 'id("com.facebook.react") version "0.80.0" apply false' here if it's already in settings.gradle.kts plugins block
    // and its classpath is provided by includeBuild.
    id("org.jetbrains.kotlin.android") version "1.9.0" apply false // Kotlin version
    id("com.google.gms.google-services") version "4.4.2" apply false // Firebase Google Services plugin
    id("com.android.library") version "8.4.0" apply false // Android Library Plugin (for modules)
}

buildscript {
    dependencies {
        val kotlinVersion = "1.9.0"
        val googleServicesVersion = "4.4.2"
        val androidGradlePluginVersion = "8.4.0"
        // val reactNativeGradlePluginVersion = "0.80.0" // This variable is no longer needed here

        classpath("com.android.tools.build:gradle:$androidGradlePluginVersion")
        // REMOVED: classpath("com.facebook.react:react-native-gradle-plugin:$reactNativeGradlePluginVersion")
        // The React Native Gradle Plugin is provided via includeBuild in settings.gradle.kts
        // Do NOT add it as a classpath dependency here.

        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlinVersion")
        classpath("com.google.gms:google-services:$googleServicesVersion")
        // REMOVED: Duplicate classpath("com.google.gms:google-services:4.4.1")
        
        classpath("com.google.firebase:firebase-crashlytics-gradle:2.9.9") // Keep if you use Crashlytics
    }
}

allprojects {
    // IMPORTANT: repositories are configured in settings.gradle.kts via dependencyResolutionManagement
    // to avoid conflicts, ensure no repositories block here.

    // Centralized SDK versions for all modules, consistent with your Firebase build.gradle
    extra["minSdkVersion"] = 24
    extra["compileSdkVersion"] = 35
    extra["targetSdkVersion"] = 35

    // React Native specific flags
    extra["hermesEnabled"] = true
    extra["jscFlavor"] = "org.webkit:android-jsc:r250230"
}

tasks.register<Delete>("clean") {
    delete(rootProject.buildDir)
}